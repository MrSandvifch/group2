﻿using System.Web.UI;

namespace $safeprojectname$.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}