﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;

    namespace $safeprojectname$
    {
        public partial class Contact : Page
        {
            /*
            private string p1;
            private DateTime p2;
            private decimal p3;
            private decimal p4;
            private decimal p5;
            private decimal p6;
            private int p7;*/

            public Contact(string p1)
            {
                // TODO: Complete member initialization
                /*his.p1 = p1;
                 this.p2 = p2;
                 this.p3 = p3;
                 this.p4 = p4;
                 this.p5 = p5;
                 this.p6 = p6;
                 this.p7 = p7;*/
            }
            protected void Page_Load(object sender, EventArgs e)
            {

            }
        }
    }
}