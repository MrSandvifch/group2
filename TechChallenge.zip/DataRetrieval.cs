﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace $safeprojectname$
{
    public static class DataRetrieval
    {
        private static string strConn = @"server=.\MSSQLSERVER2017;database=$safeprojectname$;integrated security=true;";
        public static List<Contact> AllContacts()
        {
            List<Contact> contacts = new List<Contact>();
            using (SqlConnection cn = new SqlConnection(strConn))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Monday");
                cn.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        contacts.Add(new Contact(dr.GetString(dr.GetOrdinal("ticker")),
                            dr.GetDateTime(dr.GetOrdinal("date")),
                            dr.GetDecimal(dr.GetOrdinal("open")),
                            dr.GetDecimal(dr.GetOrdinal("high")),
                            dr.GetDecimal(dr.GetOrdinal("low")),
                            dr.GetDecimal(dr.GetOrdinal("close")),
                            dr.GetInt32(dr.GetOrdinal("vol"))));
                    }
                }
            }
            return contacts;
        }
        public static void AddContact(Contact c)
        {
            using (SqlConnection cn = new SqlConnection(strConn))
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO Monday(ticker, date, open, high, low, close, vol)" +
                    " VALUES(@name,@email,@phone)", cn);
                cmd.Parameters.AddWithValue("@name", c.Ticker);
                cmd.Parameters.AddWithValue("@date", c.Date);
                cmd.Parameters.AddWithValue("@Open", c.Open);
                cmd.Parameters.AddWithValue("@High", c.High);
                cmd.Parameters.AddWithValue("@Low", c.Low);
                cmd.Parameters.AddWithValue("@Close", c.Close);
                cmd.Parameters.AddWithValue("@Vol", c.Vol);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}