﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$
{
    public partial class Contact
    {
        private System.Data.SqlTypes.SqlString sqlString;

        public Contact(string ticker, DateTime date, decimal open, decimal high, decimal low, decimal close, int vol)
        {
            Ticker = ticker;
            Date = date;
            Open = open;
            High = high;
            Low = low;
            Close = close;
            Vol = vol;
        }

        public Contact(System.Data.SqlTypes.SqlString sqlString)
        {
            // TODO: Complete member initialization
            this.sqlString = sqlString;
        }
        public string Ticker { get; set; }
        public DateTime Date { get; set; }
        public decimal Open { get; set; }
        public decimal High { get; set; }
        public decimal Low { get; set; }
        public decimal Close { get; set; }
        public decimal Vol { get; set; }
    }
}